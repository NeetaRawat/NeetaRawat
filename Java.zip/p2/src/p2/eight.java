package p2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class eight extends JFrame implements ActionListener,ItemListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	JButton b,bb;
	JCheckBox c1,c2,c3,c4,c5,c6,c7;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	int amt,q1,q2,q3,q4,q5,q6,q7;
	String s1,s2,s3,s4,s5,s6,s7;
	String amount;
	eight()
	{
		l1=new JLabel ("WELCOME TO OUR MARCELSPOT");
		l2=new JLabel("GO AHEAD WITH YOUR TASTE");
		l3=new JLabel("BEVERAGES");
		l12=new JLabel("QUANTITY");
		l4=new JLabel("SNACKS");
		l13=new JLabel("QUANTITY");
		l14=new JLabel("COST");
		l15=new JLabel("COST");
		c1=new JCheckBox("BLACK CURRENT");
		t1=new JTextField(" ");
		c2=new JCheckBox("OREO SHAKE");
		t2=new JTextField();
		c3=new JCheckBox("ICE-TEA");
		t3=new JTextField(" ");
		c4=new JCheckBox("GRILLED SANDWICH");
		t4=new JTextField(" ");
		c5=new JCheckBox("BURGER");
		t5=new JTextField(" ");
		c6=new JCheckBox("PANEER PUFF");
		t6=new JTextField(" ");
		c7=new JCheckBox("PASTA");
		t7=new JTextField(" ");
		l5=new JLabel("Rs 50/-");
		l6=new JLabel("Rs 70/-");
		l7=new JLabel("Rs 40/-");
		l8=new JLabel("Rs 60/-");
		l9=new JLabel("Rs 90/-");
		l10=new JLabel("Rs 50/-");
		l11=new JLabel("Rs 90/-");
		b=new JButton("TOTAL AMOUNT");
		bb=new JButton("BACK");
		this.add(l1);
		this.add(l2);
		this.add(l3);
		this.add(l12);
		this.add(l4);
		this.add(l13);
		this.add(l5);
		this.add(l6);
		this.add(l7);
		this.add(l8);
		this.add(l9);
		this.add(l10);
		this.add(l11);
		this.add(l14);
		this.add(l15);
		c1.addItemListener(this);
		this.add(t1);
		c2.addItemListener(this);
		this.add(t2);
		c3.addItemListener(this);
		this.add(t3);
		c4.addItemListener(this);
		this.add(t4);
		c5.addItemListener(this);
		this.add(t5);
		c6.addItemListener(this);
		this.add(t6);
		c7.addItemListener(this);
		this.add(t7);
		b.addActionListener(this);
		bb.addActionListener(this);
		setVisible(true);
		setSize(1000,900);
		setTitle("HOME PAGE OF RESTAURANT");
		Container con=getContentPane();
		con.setLayout(null);
		l1.setBounds(400,80,300,40);
		l2.setBounds(400,140,300,40);
		l3.setBounds(50,200,200,40);
		l12.setBounds(250,200,200,40);
		c1.setBounds(50,240,200,40);
		l5.setBounds(400,240,200,40);
		t1.setBounds(250,240,100,30);
		c2.setBounds(50,280,200,40);
		l6.setBounds(400,280,200,40);
	    t2.setBounds(250,280,100,30);
	    c3.setBounds(50,320,200,40);
	    l7.setBounds(400,320,200,40);
	    t3.setBounds(250,320,100,30);
	    l13.setBounds(700,200,200,40);
	    l4.setBounds(550,200,200,40);
	    c4.setBounds(550,240,200,40);
	    t4.setBounds(700,240,100,30);
	    c5.setBounds(550,280,200,40);
	    t5.setBounds(700,280,100,30);
	    c6.setBounds(550,320,200,40);
	    t6.setBounds(700,320,100,30);
	    c7.setBounds(550,360,200,40);
	    t7.setBounds(700,360,100,30);
	    l8.setBounds(850,240,200,40);
	    l9.setBounds(850,280,200,40);
	    l10.setBounds(850,320,200,40);
	    l11.setBounds(850,360,200,40);
	    l14.setBounds(400,200,100,40);
	    l15.setBounds(850,200,100,40);
	    b.setBounds(460,420,100,30);
	    bb.setBounds(460,480,100,30);
		con.add(l1);
		con.add(l2);
		con.add(l3);
		con.add(l12);
		con.add(l14);
		con.add(l4);
		con.add(c1);
		con.add(t1);
		con.add(l5);
		con.add(c2);
		con.add(t2);
		con.add(l6);
		con.add(c3);
		con.add(t3);
		con.add(l7);
		con.add(l13);
		con.add(l15);
		con.add(c4);
		con.add(t4);
		con.add(l8);
		con.add(c5);
		con.add(t5);
		con.add(l9);
		con.add(c6);
		con.add(t6);
		con.add(l10);
		con.add(c7);
		con.add(t7);
		con.add(l11);
		con.add(b);
		con.add(bb);
		con.setFont(new Font("New Times Roman",Font.BOLD,3000));
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s=ae.getActionCommand();
		if(s.equals("BACK"))
		{
			new dv();
		}
			s1=t1.getText();
			s2=t2.getText();
			s3=t3.getText();
			s4=t4.getText();
			s5=t5.getText();
			s6=t6.getText();
			s7=t7.getText();
			q1=Integer.parseInt(s1);
			q2=Integer.parseInt(s2);
			q3=Integer.parseInt(s3);
			q4=Integer.parseInt(s4);
			q5=Integer.parseInt(s5);
			q6=Integer.parseInt(s6);
			q7=Integer.parseInt(s7);
			String s8=ae.getActionCommand();
			if(s8.equals("TOTAL AMOUNT"))
			{
			boolean b1=c1.isSelected();
			boolean b2=c2.isSelected();
			boolean b3=c3.isSelected();
			boolean b4=c4.isSelected();
			boolean b5=c5.isSelected();
			boolean b6=c6.isSelected();
			boolean b7=c7.isSelected();
			if(b1==true && b4==true && b5==true && b6==true &&b7==true)
				amt=((q1*50)+(q4*60)+(q5*90)+(q6*50)+(q7*90));
			else if(b2==true && b4==true && b5==true && b6==true &&b7==true)
				amt=((q2*70)+(q4*60)+(q5*90)+(q6*50)+(q7*90));
			else if(b3==true && b4==true && b5==true && b6==true &&b7==true)
				amt=((q3*40)+(q4*60)+(q5*90)+(q6*50)+(q7*90));
			else if(b1==true && b4==true && b5==true && b6==true)
				amt=((q1*50)+(q4*60)+(q5*90)+(q6*50));
			else if(b2==true && b4==true && b5==true && b6==true)
				amt=((q2*70)+(q4*60)+(q5*90)+(q6*50));
			else if(b3==true && b4==true && b5==true && b6==true)
				amt=((q3*40)+(q4*60)+(q5*90)+(q6*50));
			else if(b1==true && b4==true && b5==true && b7==true)
				amt=((q1*50)+(q4*60)+(q5*90)+(q7*90));
			else if(b2==true && b4==true && b5==true && b7==true)
				amt=((q2*70)+(q4*60)+(q5*90)+(q7*90));
			else if(b3==true && b4==true && b5==true && b7==true)
				amt=((q3*40)+(q4*60)+(q5*90)+(q7*90));
			else if(b1==true && b4==true && b6==true && b7==true)
				amt=((q1*50)+(q4*60)+(q6*50)+(q7*90));
			else if(b2==true && b4==true && b6==true && b7==true)
					amt=((q2*70)+(q4*60)+(q6*50)+(q7*90));
			else if(b3==true && b4==true && b6==true && b7==true)
				amt=((q3*40)+(q4*60)+(q6*50)+(q7*90));
			else if(b1==true && b5==true && b6==true && b7==true)
				amt=((q1*50)+(q5*90)+(q6*50)+(q7*90));
			else if(b2==true && b5==true && b6==true && b7==true)
				amt=((q2*70)+(q5*90)+(q6*50)+(q7*90));
			else if(b3==true && b5==true && b6==true && b7==true)
				amt=((q3*40)+(q5*90)+(q6*50)+(q7*90));
			else if(b4==true && b5==true && b6==true && b7==true)
				amt=((q4*60)+(q5*90)+(q6*50)+(q7*90));
			else if(b1==true && b4==true && b5==true)
				amt=((q1*50)+(q4*60)+(q5*90));
			else if(b2==true && b4==true && b5==true)
				amt=((q2*70)+(q4*60)+(q5*90));
			else if(b3==true && b4==true && b5==true)
				amt=((q3*70)+(q4*60)+(q5*90));
			else if(b1==true && b4==true && b6==true)
				amt=((q1*50)+(q4*60)+(q6*50));
			else if(b2==true && b4==true && b6==true)
				amt=((q2*70)+(q4*60)+(q6*50));
			else if(b3==true && b4==true && b6==true)
				amt=((q3*40)+(q4*60)+(q6*50));
			else if(b1==true && b4==true && b7==true)
				amt=((q1*50)+(q4*50)+(q7*90));
			else if(b2==true && b4==true && b7==true)
				amt=((q2*70)+(q4*50)+(q7*90));
			else if(b3==true && b4==true && b7==true)
				amt=((q3*40)+(q4*50)+(q7*90));
			else if(b1==true && b5==true && b6==true)
				amt=((q1*50)+(q5*90)+(q6*50));
			else if(b2==true && b5==true && b6==true)
				amt=((q2*70)+(q5*90)+(q6*50));
			else if(b3==true && b5==true && b6==true)
				amt=((q3*40)+(q5*90)+(q6*50));
			else if(b1==true && b5==true && b7==true)
				amt=((q1*50)+(q5*90)+(q7*90));
			else if(b2==true && b5==true && b7==true)
				amt=((q2*70)+(q5*90)+(q7*90));
			else if(b3==true && b5==true && b7==true)
				amt=((q3*40)+(q5*90)+(q7*90));
			else if(b1==true && b6==true && b7==true)
				amt=((q1*50)+(q6*50)+(q7*90));
			else if(b2==true && b6==true && b7==true)
				amt=((q2*70)+(q6*50)+(q7*90));
			else if(b3==true && b6==true && b7==true)
				amt=((q3*40)+(q6*50)+(q7*90));
			else if(b1==true && b2==true && b3==true)
				amt=((q1*50)+(q2*70)+(q3*40));
			else if(b4==true && b5==true && b6==true)
				amt=((q4*60)+(q5*90)+(q6*50));
			else if(b4==true && b5==true && b7==true)
				amt=((q4*60)+(q5*90)+(q7*90));
			else if(b5==true && b6==true && b7==true)
				amt=((q5*90)+(q6*50)+(q7*90));
			else if(b4==true && b6==true && b7==true)
				amt=((q4*60)+(q6*50)+(q7*90));
			else if(b1==true && b2==true)
				amt=((q1*50)+(q2*70));
			else if(b1==true && b3==true)
				amt=((q1*50)+(q3*40));
			else if(b2==true && b3==true)
				amt=((q2*70)+(q3*40));
			else if(b4==true && b5==true)
				amt=((q4*60)+(q5*90));
			else if(b4==true && b6==true)
				amt=((q4*60)+(q6*50));
			else if(b4==true && b7==true)
				amt=((q4*60)+(q7*90));
			else if(b5==true && b6==true)
				amt=((q5*90)+(q6*50));
			else if(b5==true && b7==true)
				amt=((q5*90)+(q7*90));
			else if(b6==true && b7==true)
				amt=((q6*50)+(q7*90));
			else if(b1==true)
				amt=50;
			else if(b2==true)
				amt=70;
			else if(b3==true)
				amt=40;
			else if(b4==true)
				amt=60;
			else if(b5==true)
				amt=90;
			else if(b6==true)
				amt=50;
			else if(b7==true)
				amt=90;
			}
			amount=Integer.toString(amt);
		   try
			{
			 new mcharges(amount);
		    }
	      catch(Exception e)
			{
			System.out.println(e);
			}
		}
	   public void ItemStateChanged(ItemEvent ie)
	   {
		   
	   }

	public static void main(String s[])
	{
		eight ob8=new eight();
	}
}

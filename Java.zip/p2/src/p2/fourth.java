package p2;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class fourth extends JFrame implements ActionListener , ItemListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JButton b1;
	JRadioButton r1,r2,r3;
	JCheckBox c1,c2,c3,c4;
	String s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16, Amount;
	int days,Amt;
	fourth()
	{
		l1=new JLabel("NAME");
		l2=new JLabel("CONTACT");
		l3=new JLabel("E-MAIL");
		l4=new JLabel("ADHAAR NO.");
		l5=new JLabel("ADDRESS");
		l6=new JLabel("TYPE OF ROOM CHOOSED");
		r1=new JRadioButton("PENT HOUSE");
		r2=new JRadioButton("DELUXE");
		r3=new JRadioButton("LUXURY");
		l7=new JLabel("NO.OF DAYS");
		l8=new JLabel("ARRIVAL DATE");
		l9=new JLabel("DEPARTURE DATE");
		l10=new JLabel("ADDITIONAL FACILITIES");
		c1=new JCheckBox("NONE");
		c2=new JCheckBox("GYM");
		c3=new JCheckBox("LAUNDRY");
		c4=new JCheckBox("CASEENO");
		t1=new JTextField();
		t2=new JTextField();
		t3=new JTextField();
		t4=new JTextField();
		t5=new JTextField();
		t6=new JTextField();
		t7=new JTextField(" / / ");
		t8=new JTextField(" / / ");
		b1=new JButton("AMOUNT");
		this.add(l1);
		this.add(l2);
		this.add(l3);
		this.add(l4);
		this.add(l5);
		this.add(l6);
		r1.addActionListener(this);
		r2.addActionListener(this);
		this.add(r3);
		this.add(l7);
		this.add(l8);
		this.add(l9);
		this.add(l10);
		c1.addItemListener(this);
		c2.addItemListener(this);
		c3.addItemListener(this);
		c4.addItemListener(this);
		this.add(t1);
		this.add(t2);
		this.add(t3);
		this.add(t4);
		this.add(t5);
		this.add(t6);
		this.add(t7);
		this.add(t8);
		b1.addActionListener(this);
		setVisible(true);
		setSize(800,800);
		setTitle("ENROLLMENT FORM");
		setFont(new Font("New Times Roman",Font.BOLD,100));
		Container con=getContentPane();
		con.setLayout(null);
		ButtonGroup bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		l1.setBounds(50,80,100,30);
		t1.setBounds(180,80,100,30);
		l2.setBounds(50,120,100,30);
		t2.setBounds(180,120,100,30);
		l3.setBounds(50,160,100,30);
		t3.setBounds(180,160,100,30);
		l4.setBounds(50,200,100,30);
		t4.setBounds(180,200,100,30);
		l5.setBounds(50,240,100,30);
		t5.setBounds(180,240,100,30);
		l6.setBounds(50,280,100,30);
		r1.setBounds(180,280,100,30);
		r2.setBounds(280,280,100,30);
		r3.setBounds(380,280,100,30);
		l7.setBounds(50,320,100,30);
		t6.setBounds(180,320,100,30);
		l8.setBounds(50,360,100,30);
		t7.setBounds(180,360,100,30);
		l9.setBounds(50,400,100,30);
		t8.setBounds(180,400,100,30);
		l10.setBounds(50,440,100,30);
		c1.setBounds(180,440,100,30);
		c2.setBounds(180,480,100,30);
		c3.setBounds(180,520,100,30);
		c4.setBounds(180,560,100,30);
		b1.setBounds(50,600,100,30);
		con.add(l1);
		con.add(t1);
		con.add(l2);
		con.add(t2);
		con.add(l3);
		con.add(t3);
		con.add(l4);
		con.add(t4);
		con.add(l5);
		con.add(t5);
		con.add(l6);
		con.add(r1);
		con.add(r2);
		con.add(r3);
		con.add(l7);
		con.add(t6);
		con.add(l8);
		con.add(t7);
		con.add(l9);
		con.add(t8);
		con.add(l10);
		con.add(c1);
		con.add(c2);
		con.add(c3);
		con.add(c4);
		con.add(b1);
		addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent we)
					{
						System.out.print(0);
					}
				});
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s=ae.getActionCommand();
		if(s.equals("AMOUNT"))
		{
			s1=t1.getText();
		    s2=t2.getText();
		    s3=t3.getText();
		    s4=t4.getText();
		    s5=t5.getText();
		    s7=t6.getText();
		    days = Integer.parseInt(s7);
		    s8=t7.getText();
		    s9=t8.getText();
		    boolean b1=r1.isSelected();
		    boolean b2=r2.isSelected();
		    boolean b3=r3.isSelected();
		    boolean b4=c1.isSelected();
		    boolean b5=c2.isSelected();
		    boolean b6=c3.isSelected();
		    boolean b7=c4.isSelected();
		    if(b1==true)
		    	s6="PENT HOUSE";
		    else if(b2==true)
		    	s6="DELUXE";
		    else if(b3==true)
		    	s6="LUXURY";
		   // if(b4==true)
		    	//s8="NONE";
		    if(b5==true && b6==true && b7==true)
		    {
		    	s10="GYM,LAUNDRY,CASEENO";
		    }
		    else if(b5==true && b6==true)
		    {
		    	s10="GYM,LAUNDRY";
		    }
		    else if(b5==true && b7==true)
		    {
		    	s10="GYM,CASEENO";
		    }
		    else if(b6==true && b7==true)
		    {
		    	s10="LAUNDRY,CASEENO";
		    }
		    else if(b5==true)
		    	s10="GYM";
		    else if(b6==true)
		    {
		    	s10="LAUNDRY";
		    }
		    else if(b7==true)
		    {
		    	s10="CASEENO";
		    }
		    
		    else if(b4 == true)
		    {
		    	s10="NONE";
		    }
		    
		    if(b1 == true)
		    {
		    	if(b5 == true && b6 == true && b7==true)
		    		Amt=(days*1000)+750;
		    	else if(b5==true && b6==true)
		    		Amt=(days*1000)+250;
		    	else if(b5==true && b7==true)
		    		Amt=(days*1000)+700;
		    	else if(b6==true &&b7==true)
		    		Amt=(days*1000)+550;
		    	else if(b5==true)
		    		Amt=(days*1000)+200;
		    	else if(b6==true)
		    		Amt=(days*1000)+50;
		    	else if(b7==true)
		    		Amt=(days*1000)+500;
		    	else if(b4==true)
		    		Amt=(days*1000);
		    }
			else if(b2 == true)
			{
			 	if(b5 == true && b6 == true && b7==true)
		    		Amt=(days*1500)+750;
		    	else if(b5==true && b6==true)
		    	
		    		Amt=(days*1500)+250;
		    	else if(b5==true && b7==true)
		    		Amt=(days*1500)+700;
		    	else if(b6==true &&b7==true)
		    	
		    		Amt=(days*1500)+550;
		    	
		    	else if(b5==true)
		    	
		    		Amt=(days*1500)+200;
		    	
		    	else if(b6==true)
		    		Amt=(days*1500)+50;
		    	else if(b7==true)
		    		Amt=(days*1500)+500;
		    	else if(b4==true)
		    		Amt=(days*1500);
		    }
			else if(b3==true)
			{
			 	if(b5 == true && b6 == true && b7==true)
		    		Amt=(days*2000)+750;
		    	else if(b5==true && b6==true)
		    	
		    		Amt=(days*2000)+250;
		    	
		    	else if(b5==true && b7==true)
		    		Amt=(days*2000)+700;
		    	
		    	else if(b6==true &&b7==true)
		    	
		    		Amt=(days*2000)+550;
		    	
		    	else if(b5==true)
		    	
		    		Amt=(days*2000)+200;
		    	
		    	else if(b6==true)
		    	
		    		Amt=(days*2000)+50;
		    	
		    	else if(b7==true)
		    	
		    		Amt=(days*2000)+500;
		    	
		    	else if(b4==true)
		    	
		    		Amt=(days*2000);
		  
		    }
			Amount=Integer.toString(Amt);
		    try
		    {
		    	Class.forName("com.mysql.jdbc.Driver");
		    	Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3307/javainn","root","root");
		    	Statement stm=cn.createStatement();
		    	stm.executeUpdate("insert into records values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+days+"','"+s8+"','"+s9+"','"+s10+"', '"+Amount+"')");
		    	new charges(Amount);
		    	setVisible(false);
		    }
		    catch(Exception e)
		    {
		    	System.out.println(e);
		    }
		}
	}
	public void itemStateChanged(ItemEvent ie)
	{
		
	}
	public static void main(String s[])
	{
		fourth ob4=new fourth();
	}
}

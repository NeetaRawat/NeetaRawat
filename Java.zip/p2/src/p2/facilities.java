package p2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class facilities extends JFrame implements ActionListener, ItemListener
{
	JLabel l1,l2,l3,l4,l6,l7,l8,l9,l11,l10,l12;
	JCheckBox c1,c2,c3,c4;
	JButton b1,b2;
	int amt;
	String amount;
	facilities()
	{
	l1=new JLabel("WELCOME TO EXTRA-SPOT");
	l12=new JLabel("ONLY ONE PERSON AT A TIME ");
	c1=new JCheckBox("GYM");
	l11=new JLabel("FACILITY");
	l2=new JLabel("PROPER TRAINER AND EQUIPMENTS ARE AVAILABLE");
	c2=new JCheckBox("CASINO AND GAMING");
	l3=new JLabel("8 BALL POOL AND BALLING ARE AVAILABLE");
	c3=new JCheckBox("SWIMMING POOL");
	l4=new JLabel("PROPER TRAINER IS AVAILABLE");
	c4=new JCheckBox("EXTRA CHARGES FOR SWIMMING COSTUME");
	l10=new JLabel("COST");
	l6=new JLabel("2000");
	l7=new JLabel("1500");
	l8=new JLabel("2200");
	l9=new JLabel("700");
	b1=new JButton("TOTAL AMOUNT");
	b2=new JButton("BACK");
	Container tre=getContentPane();
	tre.setLayout(null);
	b1.addActionListener(this);
	b2.addActionListener(this);
	c1.addItemListener(this);
	c2.addItemListener(this);
	c3.addItemListener(this);
	c4.addItemListener(this);
	l1.setBounds(50,80,200,40);
	l12.setBounds(300,20,400,40);
	l10.setBounds(800,80,200,40);
	l11.setBounds(250,80,200,40);
	c1.setBounds(50,120,200,40);
	l2.setBounds(250,120,400,40);
	l6.setBounds(800,120,200,40);
	c2.setBounds(50,160,250,40);
	l3.setBounds(250,160,400,40);
	l7.setBounds(800,160,400,40);
	c3.setBounds(50,200,200,40);
	l4.setBounds(250,200,300,40);
	l8.setBounds(800,200,200,40);
	l9.setBounds(800,250,200,40);
	c4.setBounds(50,250,400,40);
	b1.setBounds(250,400,200,40);
	b2.setBounds(500,400,200,40);
	tre.add(l1);
	tre.add(l12);
	tre.add(l2);
	tre.add(l10);
	tre.add(l11);
	tre.add(l3);
	tre.add(l4);
	tre.add(c4);
	tre.add(l6);
	tre.add(l7);
	tre.add(l8);
	tre.add(l9);
	tre.add(c1);
	tre.add(c2);
	tre.add(c3);
	tre.add(b1);
	tre.add(b2);
	addWindowListener(new WindowAdapter() 
			{
		public void windowClosing(WindowEvent we)
		{
			System.exit(0);
		}
		});
	setVisible(true);
	setSize(1000,1000);
	setTitle("EXTRA FACILITIES FOR DAILY VISITORS");
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s=ae.getActionCommand();
		if(s.equals("BACK"))
		{
			new dv();
		}
		String s1=ae.getActionCommand();
		if(s1.equals("TOTAL AMOUNT"))
		{	
			boolean b1=c1.isSelected();
			boolean b2=c2.isSelected();
			boolean b3=c3.isSelected();
			boolean b4=c4.isSelected();
			if(b1==true && b2==true && b3==true &&b4==true)
				amt=(2000+2000+2200+700);
			else if(b1==true && b2==true && b3==true)
				amt=(2000+2000+2200);
			else if(b1==true && b3==true && b4==true)
				amt=(2000+2200+700);
			else if(b2==true && b3==true && b4==true)
				amt=(2000+2200+700);
			else if(b1==true && b2==true)
				amt=(2000+2000);
			else if(b1==true &&b3==true)
				amt=(2000+2200);
			else if(b2==true && b3==true)
				amt=(2000+2200);
			else if(b1==true)
				amt=2000;
			else if(b2==true)
				amt=2000;
			else if(b3==true)
				amt=2000;
			amount=Integer.toString(amt);
			try
			{
			new fcharges(amount);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
	public void itemStateChanged(ItemEvent ie)
	{
		
	}
	public static void main(String s[])
	{
		facilities ob14=new facilities();
	}
	}
	
	
	
	
	
	
	


package p2;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
public class mcharges extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1,b2;
	mcharges(String amount)
	{
		l1=new JLabel("TOTAL AMOUNT : Rs"+" "+amount);
		b1=new JButton("BACK");
		b2=new JButton("OK");
		this.add(l1);
		b1.addActionListener(this);
		b2.addActionListener(this);
		setVisible(true);
		setTitle("CHARGES FOR MARCEL");
		setSize(1000,900);
		setFont(new Font("New Times Roman",Font.BOLD,1000));
		Container con=getContentPane();
		con.setLayout(null);
		l1.setBounds(300,100,300,40);
		b1.setBounds(120,300,100,40);
		b2.setBounds(120,350,100,40);
		con.add(l1);
		con.add(b1);
		con.add(b2);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
	}
    public void actionPerformed(ActionEvent ae)
    {
    	String s1=ae.getActionCommand();
    	if(s1.equals("BACK"))
    	{
    		new eight();
    	}
    	String s2=ae.getActionCommand();
    	if(s2.equals("OK"))
    	{
    		setVisible(false);
    	}
    }
    public static void main(String s[])
    {
    	mcharges ob1=new mcharges("amount");
    }
}


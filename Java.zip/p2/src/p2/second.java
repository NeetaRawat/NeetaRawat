package p2;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class second extends JFrame implements ActionListener
	{
		JButton b3,b4,b5,b6;
		second()
		{
			b3=new JButton("PENT HOUSE");
			b4=new JButton("DELUXE");
			b5=new JButton("LUXURY");
			b6=new JButton("BACK");
				Container con=getContentPane();
				con.setLayout(null);
				b3.addActionListener(this);
				b4.addActionListener(this);
				b5.addActionListener(this);
				b6.addActionListener(this);
				b3.setBounds(100,300,200,40);
				b4.setBounds(400,300,200,40);
				b5.setBounds(700,300,200,40);
				b6.setBounds(400,380,200,40);
				con.add(b3);
				con.add(b4);
				con.add(b5);
				con.add(b6);
				setSize(1000,900);
				setVisible(true);
				setTitle("ROOM TYPES");
				setFont(new Font("New Times Roman",Font.BOLD,100));
			addWindowListener(new WindowAdapter()
					{
					public void windowClosing(WindowEvent we)
					{
						System.exit(0);
					}
					});
		}
		public void actionPerformed(ActionEvent ae)
		{
			String s1=ae.getActionCommand();
			if(s1.equals("PENT HOUSE"))
			{
				new third();
			}
			String s2=ae.getActionCommand();
			if(s2.equals("BACK"))
			{
				new first();
			}
			String s3=ae.getActionCommand();
			if(s3.equals("DELUXE"))
			{
				new sixth();
			}
			String s4=ae.getActionCommand();
			if(s4.equals("LUXURY"))
			{
				new seventh();
			}
		}
		public static void main(String s[])
		{
			second ob1=new second();
	
		
		}
	}

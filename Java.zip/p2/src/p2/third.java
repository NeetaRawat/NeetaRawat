package p2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class third extends JFrame implements ActionListener
	{
		JButton b6,b7,b8;
		JLabel l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24;
		third()
		{
			l2=new JLabel("RENT FOR PENT HOUSE");
			l3=new JLabel("DAYS(S)");
			l4=new JLabel("1");
			l5=new JLabel("2");
			l6=new JLabel("3");
			l7=new JLabel("4");
			l8=new JLabel("5");
			l9=new JLabel("6");
			l10=new JLabel("7");
			l11=new JLabel("COST(in Rs)");
			l12=new JLabel("1000");
			l13=new JLabel("2000");
			l14=new JLabel("3000");
			l15=new JLabel("4000");
			l16=new JLabel("5000");
			l17=new JLabel("5000");
			l18=new JLabel("6000");
			l20=new JLabel("FACILITIES");
			l21=new JLabel("2BK");
			l22=new JLabel("WiFi");
			l23=new JLabel("24 hrs Electricity & Water");
			l24=new JLabel("SWIMMING POOL");
			l19=new JLabel("EXTRA CHARGES FOR AC ROOM ARE Rs-300/day ");
			b6=new JButton("ENROLL");
			b7=new JButton("BACK");
			b8=new JButton("EXTRA FACILITIES");
			this.add(l2);
			this.add(l3);
			this.add(l3);
			this.add(l5);
			this.add(l6);
			this.add(l7);
			this.add(l8);
			this.add(l9);
			this.add(l10);
			this.add(l11);
			this.add(l12);
			this.add(l13);
			this.add(l14);
			this.add(l15);
			this.add(l16);
			this.add(l17);
			this.add(l18);
			this.add(l19);
			this.add(l20);
			this.add(l21);
			this.add(l22);
			this.add(l23);
			this.add(l24);
			b6.addActionListener(this);
			b7.addActionListener(this);
			b8.addActionListener(this);
			setVisible(true);
			setSize(800,800);
			setTitle("RENT & FACILITIES");
			setFont(new Font("New Times Roman",Font.BOLD,100));
			Container cone=getContentPane();
			cone.setLayout(null);
			l2.setBounds(200,50,200,40);
			l3.setBounds(100,100,200,40);
			l4.setBounds(100,140,200,40);
			l5.setBounds(100,180,200,40);
			l6.setBounds(100,220,200,40);
			l7.setBounds(100,260,200,40);
			l8.setBounds(100,300,200,40);
			l9.setBounds(100,340,200,40);
			l10.setBounds(100,380,200,40);
			l11.setBounds(400,100,200,40);
			l12.setBounds(400,140,200,40);
			l13.setBounds(400,180,200,40);
			l14.setBounds(400,220,200,40);
			l15.setBounds(400,260,200,40);
			l16.setBounds(400,300,200,40);
			l17.setBounds(400,340,200,40);
			l18.setBounds(400,380,200,40);
			l19.setBounds(150,420,300,40);
			l20.setBounds(100,460,200,40);
			l21.setBounds(400,460,200,40);
			l22.setBounds(400,500,200,40);
			l23.setBounds(400,540,200,40);
			l24.setBounds(400,580,200,40);
			b6.setBounds(150,620,150,40);
			b7.setBounds(450,620,100,40);
			b8.setBounds(750,620,300,40);
			cone.add(l2);
			cone.add(l3);
			cone.add(l4);
			cone.add(l5);
			cone.add(l6);
			cone.add(l7);
			cone.add(l8);
			cone.add(l9);
			cone.add(l10);
			cone.add(l11);
			cone.add(l12);
			cone.add(l13);
			cone.add(l14);
			cone.add(l15);
			cone.add(l16);
			cone.add(l17);
			cone.add(l18);
			cone.add(l19);
			cone.add(l20);
			cone.add(l21);
			cone.add(l22);
			cone.add(l23);
			cone.add(l24);
			cone.add(b6);
			cone.add(b7);
			cone.add(b8);
			addWindowListener(new WindowAdapter()
					{
						public void windowClosing(WindowEvent we)
						{
							System.exit(0);
						}
					});
		}
		public void actionPerformed(ActionEvent ae)
		{
			String s2=ae.getActionCommand();
			if(s2.equals("BACK"))
			{
				new second();
			}
			String s3=ae.getActionCommand();
			if(s3.equals("EXTRA FACILITIES"))
			{
				new fifth();
			}
			String s4=ae.getActionCommand();
			if(s4.equals("ENROLL"))
			{
				new fourth();
			}
		}
		public static void main(String s[])
		{
			third ob2=new third();
		}
	}

package p2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class charges extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton b,bb;
	JRadioButton r1,r2,r3;
	charges(String Amount)
	{
		l1=new JLabel("TOTAL AMOUNT : Rs"+ "  " +Amount);
		l2=new JLabel("MODE OF PAYMENT");
		r1=new JRadioButton("BY CASH");
		r2=new JRadioButton("BY CREDIT CARD");
		r3=new JRadioButton("NONE");
		b=new JButton("OK");
		bb=new JButton("CANCEL");
		this.add(l1);
		this.add(l2);
		b.addActionListener(this);
		bb.addActionListener(this);
		r1.addActionListener(this);
		r2.addActionListener(this);
		r3.addActionListener(this);
		setVisible(true);
		setSize(1000,900);
		setTitle("Thanks For Visit");
		setFont(new Font("New Times Roman",Font.BOLD,1000));
		Container con=getContentPane();
		con.setLayout(null);
		ButtonGroup bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		l1.setBounds(300,100,300,40);
		l2.setBounds(100,200,200,40);
		r1.setBounds(120,300,200,40);
		r2.setBounds(120,350,200,40);
		r3.setBounds(120,400,200,40);
		b.setBounds(200,450,100,40);
		bb.setBounds(400,450,100,40);
		con.add(l1);
		con.add(l2);
		con.add(r1);
		con.add(r2);
		con.add(r3);
		con.add(b);
		con.add(bb);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s1=ae.getActionCommand();
		if(s1.equals("OK"))
		{
			boolean b1=r1.isSelected();
			boolean b2=r2.isSelected();
			if(b1==true)
			{
				setVisible(false);
			}
		}
		else if(s1.equals("CANCEL"))
		{
			boolean b3=r3.isSelected();
			if(b3==true)
			{
				new first();
			}
		}
		
	}
	public void itemStateChanged(ItemEvent ie)
	{
	
	}
	public static void main(String s[])
	{
		charges ob=new charges("Amount");
	}
	
}

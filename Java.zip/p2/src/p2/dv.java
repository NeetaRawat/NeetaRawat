package p2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class dv extends JFrame implements ActionListener
{
	JButton b1,b2;
	JRadioButton r1,r2;
	dv()
	{
		r1=new JRadioButton("MARCEL");
		r2=new JRadioButton("EXTRA FACILITIES");
		b2=new JButton("BACK");
		setVisible(true);
		setTitle("HOME PAGE FOR DAILY VISIT");
		setSize(800,700);
		setFont(new Font("New Times Roman",Font.BOLD,1000));
		Container con=getContentPane();
		con.setLayout(null);
		r1.addActionListener(this);
		r2.addActionListener(this);
		b2.addActionListener(this);
		ButtonGroup bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		r1.setBounds(200,100,200,40);
		r2.setBounds(500,100,300,40);
		b2.setBounds(350,200,200,40);
		con.add(r1);
		con.add(r2);
		con.add(b2);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
			boolean b3=r1.isSelected();
			if(b3==true)
			{
				new eight();
			}
			boolean b4=r2.isSelected();
			if(b4==true)
			{
				new facilities();
			}
			String s1=ae.getActionCommand();
			if(s1.equals("BACK"))
			{
				new first();
			}
	}
	public static void main(String s[])
	{
		dv ob=new dv();
	}

}

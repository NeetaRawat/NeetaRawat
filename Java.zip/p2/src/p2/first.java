package p2;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class first extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1,b2,b3;
	 first()
	{
		l1=new JLabel("WELCOME TO JAVA INN");
		b1=new JButton("BOOK ROOM");
		b2=new JButton("DAILY VISIT");
		b3=new JButton("HALL BOOKING");
		this.add(l1);
		Container cn=getContentPane();
		cn.setLayout(null);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		l1.setBounds(350, 100, 300,40);
		b1.setBounds(100,300,200,40);
		b2.setBounds(500,300,200,40);
		b3.setBounds(800,300,200,40);
		
	    cn.add(l1);
		cn.add(b1);
		cn.add(b2);
		cn.add(b3);
		addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent we)
					{
						System.exit(0);
					}
				});
		
		setVisible(true);
		setSize(1000,1000);
		setTitle("HOME PAGE");
		setFont(new Font("New Times Roman",Font.BOLD,100));
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s1=ae.getActionCommand();
		if(s1.equals("BOOK ROOM"))
		{
			new second();
		}
		else if(s1.equals("DAILY VISIT"))
		{
			new dv();
		}
		else if(s1.equals("HALL BOOKING"))
		{
			
		}

		setVisible(false);
	}
	public static void main(String s[])
	{
		first ob=new first();
	}
}

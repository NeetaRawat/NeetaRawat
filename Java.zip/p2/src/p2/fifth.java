package p2;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class fifth extends JFrame implements ActionListener
{
		JLabel l25,l26,l27,l28,l29,l30,l31,l32,l33,l34;
		JButton b9;
		fifth()
		{
			l25=new JLabel("FACILITIES");
			l26=new JLabel("Gym");
			l27=new JLabel("Laundary");
			l28=new JLabel("Caseeno");
			l29=new JLabel("CHARGES/Person(in Rs)");
			l30=new JLabel("200");
			l31=new JLabel("50");
			l32=new JLabel("500");
			b9=new JButton("BACK");
			this.add(l25);
			this.add(l26);
			this.add(l27);
			this.add(l28);
			this.add(l29);
			this.add(l30);
			this.add(l31);
			this.add(l32);
			b9.addActionListener(this);
			setVisible(true);
			setSize(600,600);
			setTitle("EXTRA FACILITIES & CHARGES");
			setFont(new Font("New Times Roman",Font.BOLD,100));
			Container cone=getContentPane();
			cone.setLayout(null);
			l25.setBounds(100,100,200,40);
			l26.setBounds(100,140,200,40);
			l27.setBounds(100,180,200,40);
			l28.setBounds(100,220,200,40);
			l29.setBounds(400,100,200,40);
			l30.setBounds(400,140,200,40);
			l31.setBounds(400,180,200,40);
			l32.setBounds(400,220,200,40);
			b9.setBounds(200,300,200,40);
			cone.add(l25);
			cone.add(l26);
			cone.add(l27);
			cone.add(l28);
			cone.add(l29);
			cone.add(l30);
			cone.add(l31);
			cone.add(l32);
			cone.add(b9);
			addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					System.exit(0);
				}
			});
		}
		public void actionPerformed(ActionEvent ae)
		{
			String s1=ae.getActionCommand();
					if(s1.equals("BACK"))
					{
						new third();
					}
		}
		public static void main(String s[])
		{
			fifth ob5=new fifth();
		}

}
